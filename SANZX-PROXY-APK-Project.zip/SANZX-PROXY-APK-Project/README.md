# SANZX PROXY Android demo

A basic Android WebView wrapper for the SANZX PROXY HTML prototype.

Important: the Connect button is a UI demo only. This project does not create a VPN tunnel or connect to a VLESS/proxy server.

Build with Gradle 8.9 and JDK 17: `gradle assembleDebug`.
